# Risk & Tradeability — Drop-in Guide

## What this pack adds
- **ATR-based SL/TP** and **%equity position sizing**
- **Spread/slippage/fees awareness** (bps model)
- **Exchange constraints** (minNotional, minQty, step sizes)
- **Execution validator** for basic pre-trade checks
- **TradableSignal** composer from screening output

## Files
- `backend/screener/risk.engine.ts`
- `backend/screener/execution.validator.ts`
- `backend/screener/fees.ts`
- `backend/screener/position.sizing.ts`
- `backend/screener/trade.signal.ts`

## Quick usage
```ts
import { composeTradableSignal } from './trade.signal';

// From your screening result:
const screen = { symbol:'SOLUSDT', label:'BUY', score:78, summary:'SMC:+20 IND:+10 DER:+3 → 78', layers:{} };

// Recent candles for ATR calc (e.g., 500 latest 5m candles)
const candles = yourFetcher.getCandles('SOLUSDT', '5m', 500);

const exch = {
  minNotional: 5, minQty: 0.001, qtyStep: 0.001, priceStep: 0.01,
  takerFeeRate: 0.0005, slippageBps: 10, spreadBps: 5
};

const risk = {
  accountEquity: 10000, riskPerTradePct: 0.5, atrSLMult: 1.5,
  tp1RR: 1.5, tp2RR: 2.5, capPositionPct: 20
};

const trade = composeTradableSignal(screen, candles, risk, exch);
console.log(trade);
```

## Notes
- For **per-exchange profiles**, see `fees.ts` and keep constants in `.env`/config store.
- If you pass **leverage**, keep `riskPerTradePct` on equity; notional sizing will adjust by SL distance.
- You can validate order conditions using `execution.validator.ts` with current orderbook snapshot.
```ts
import { validateExecution } from './execution.validator';
const check = validateExecution({ symbol:'SOLUSDT', side:'long', price:trade.entry!, qty:trade.qty!, allowedSlippageBps:15, maxImpactBps:20 }, { bestBid: 199.9, bestAsk: 200.1, mid: 200.0 });
if (!check.ok) console.warn(check.reasons, check.warnings);
```
